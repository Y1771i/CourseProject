


import { createRouter, createWebHistory } from 'vue-router';
import HomePage from './views/HomePage.vue';
import CoursesPage from './views/CoursesPage.vue';
import LibraryPage from './views/LibraryPage.vue';
import ProfilePage from './views/ProfilePage.vue';
import AboutPage from './views/AboutPage.vue';

const routes = [
  { path: '/', name: 'Home', component: HomePage },
  { path: '/courses', name: 'Courses', component: CoursesPage },
  { path: '/library', name: 'Library', component: LibraryPage },
  { path: '/profile', name: 'Profile', component: ProfilePage },
  { path: '/about', name: 'About', component: AboutPage },

  { path: '/:pathMatch(.*)*', redirect: '/' }, 
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;