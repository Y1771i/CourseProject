<template>
    <section class="courses">
      <h1 class="title">Наши курсы</h1>
      <Blur />
      <CourseBlock />
      <Blur />
      <CourseBlock />
      <Blur />
      <CourseBlock />
    </section>
  </template>
  
  
<script>
  import CourseBlock from '../second_Page/CourseBlock.vue'
import Blur from '../ui/Blur.vue';
  
  export default {
    components: { 
        CourseBlock,
        Blur
    }
  }
</script>

  <style scoped>
  .courses {
    text-align: center;
    margin: 0px;
  }
  .title {
    color: #FDFDFB;
    font-family: 'Inter', sans-serif;
    font-size: 40px;
    font-weight: 400;
    padding: 75px;
  }
  </style>