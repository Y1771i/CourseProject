<template>
    <div class="course-card">
      <h2>Курс Название</h2>
      <p class="description">Описание курса. Здесь будет текст о содержании и целях обучения.</p>
      <p class="li">Курс включает в себя:</p>
      <ul>
        <li>четыре</li>
        <li>основы</li>
        <li>этого</li>
        <li>курса</li>
      </ul>
      <button>Начать курс</button>
    </div>
  </template>



<script>



export default {
  name: 'CourseBlock',
};
</script>



  <style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap');

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  
  .course-card h2 {
    font-size: 30px;
    line-height: 100%;
    font-family: 'Inter', sans-serif;
    font-weight: 400;
    margin-bottom: 38px;
  }
  
  .description {
    font-size: 16px;
    line-height: 100%;
    font-family: 'Inter', sans-serif;
    font-weight: 400;
    margin-bottom: 28px;
  }

  .course-card ul li{
    font-size: 16px;
    line-height: 100%;
    margin-left: 50px;
  }

  .course-card {
    width: 1048px;
    padding: 30px;
    text-align: left;
    margin: 40px auto;
    border-radius: 12px;
    color: white;
  }
  button {
    display: block;
    width: 60%;
    padding: 10px;
    margin-top: 40px;
    margin-left: 14rem;
    background: linear-gradient(90deg, white, #C0EFFF);
    border: none;
    border-radius: 25px;
    font-size: 20px;
    cursor: pointer;
  }
  </style>