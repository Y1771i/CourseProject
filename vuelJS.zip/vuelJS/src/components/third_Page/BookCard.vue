<template>
    <div class="book-card">
      <img :src="image" alt="book cover" class="book-image" />
      <h3>{{ title }}</h3>
      <p>{{ description }}</p>
      <button>Читать больше...</button>
    </div>
  </template>
  
  <script>

  export default {
    name: 'BookCard',
    props: {
      image: String,
      title: String,
      description: String,
    }
  }
  </script>
  



  <style scoped>
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap');
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }


  .book-card {
    background-color: #e0f1ff;
    border-radius: 16px;
    
    height: 400px;
    width: 318px;
    text-align: center;
    font-family: 'DM Serif Display', serif;
    font-size: 20px;
    font-weight: 400;
  }
  
  .book-card img {
    width: 100%;
    border-radius: 16px;
  }
  
  .book-card button {
    background-color: #0ca6b4;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 5px;
    margin-top: 10px;
    cursor: pointer;
  }
  </style>