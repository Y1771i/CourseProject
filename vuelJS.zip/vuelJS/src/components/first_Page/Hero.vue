<template>
    <header class="hero">
      <h1 class="hero-font">Добро пожаловать в мир<br>оптических систем связи</h1>
    </header>
  </template>

<script>
  export default {
    name: 'Hero'
  };
</script>
  
  <style>
@import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap');
  
.hero {
    /* background-image: url('../../assets/Slider.png'); */
    background-size: cover;
    background-position: center;
    text-align: center;
    padding: 220px 0;
    color: white;
    animation: slide 15s ease-in-out infinite;
  }

  @keyframes slide {
  0% {
    background-image: url('../../assets/Slider.png');
  }
  50% {
    background-image: url('../../assets/optika2.jpg');
  }
  100% {
    background-image: url('../../assets/hero_img3.png');
  }
}

.hero-font {
    font-family: 'Manrope', sans-serif;
    font-size: 70px;
    font-weight: 400;
    text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
    color: white;
    text-align: center;
  }
  </style>