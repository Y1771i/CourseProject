<template>

  <div class="courses-section">

    <h2>Бесплатные курсы</h2>
    <div class="card-row">
      <div class="course-card">
        Начальный <button>Подробнее</button>
      </div>

      <div class="course-card">
        Средний <button>Подробнее</button>
      </div>

      <div class="course-card">
        Проме-<br />жуточный 
        <button>Подробнее</button>
      </div>

    </div> 

    <h2>Платные курсы</h2>
    <div class="card-row center">
      <div class="course-card large">
        Продвинутый 
        <button>Подробнее</button>
      </div>
    </div>
  </div>

</template>




<script>
export default {
  props: {
    title: String,
  },
};
</script>



<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap");



.courses-section {
  text-align: center;
  font-family: 'Inter', sans-serif;
  font-weight: 400;
}

.courses-section h2 {
  font-size: 40px;
  font-weight: 300;
}

.card-row {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 32px;
  margin: 54px 0;
}

.course-card {
  background-color: #0095a9;
  border-radius: 12px;

  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  font-size: 18px;
  position: relative;
  color: white;
  padding: 90px 50px;
}

.course-card.large {
  width: 220px;
  height: 220px;
}

.course-card button {
  margin-top: 16px;
  padding: 6px 14px;
  background-color: white;
  border: none;
  border-radius: 16px;
  font-size: 15px;
  cursor: pointer;
  color: #0095a9;
}

.card-row.center {
  justify-content: center;
}
</style>
