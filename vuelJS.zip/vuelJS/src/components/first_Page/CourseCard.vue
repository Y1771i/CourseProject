
<template>
    <div class="course-card">
      {{ title }}
      <button>Подробнее</button>
    </div>
  </template>
  
  <script>
  export default {
    
    props: {
      title: String
    }
  }
  </script>
  
  <style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap');



  .course-card {
    display:inline-block;
    background: #0ca6b4;
    padding: 1rem;
    font-family:'Inter', sans-serif;
    font-size: 40px;
    border-radius: 12px;
    width: 263px;
    height: 370px;
    text-align: center;
  }
  .course-card button {
    position: relative;
    top: 50%;
    padding-top: 280px;
    padding: 0.3rem 1rem;
    border: none;
    border-radius: 5px;
    background: white;
    color: #0ca6b4;
    cursor: pointer;
  }
  </style>