<template>
    <section class="info-card">
    <div class="grid-item">
      <img src="../../assets/fiber1.png" alt="Оптика 1">
      <p>Коротко о том что такое Оптика или оптические системы связи</p>
    </div>
    <div class="grid-item">
      <p>В чём преимущество оптики над витой парой</p>
      <img src="../../assets/fiber2.png" alt="Оптика 2">
    </div>
    <div class="grid-item">
      <img src="../../assets/fiber3.png" alt="Оптика 3">
      <p>Какие виды оптики существуют на сегодняшний день</p>
    </div>
  </section>
  
</template>
  
  <script>
  export default {
    name: 'InfoCard',
    }
  </script>
  



<style>

.info-card {
  display: flex;
  flex-direction: column;
  gap: 60px;
  padding-top: 229px;
  padding-bottom: 345px;
  max-width: 1000px;
  margin: 0 auto;
  border-bottom: 5px #0D1528 solid;
}


.grid-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 40px;
  flex-wrap: wrap;
}

.grid-item img {
  width: 460px;
  max-width: 100%;
  border-radius: 8px;
}

.grid-item p {
  max-width: 400px;
  font-size: 26px;
  padding: 0 50px;
  line-height: 100%;
}


  </style>