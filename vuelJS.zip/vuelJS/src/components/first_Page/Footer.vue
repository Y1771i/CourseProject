<template>
    <footer class="footer">
      <img src="../../assets/mail.png" alt="Logo" width="35" height="30" />
      <p>fiberify@gmail.com</p>
      <p>TUIT + Reality ©<br>Since 2023</p>
    </footer>
  </template>
  
  <script>
  export default {
    name: 'Footer'
  };  
</script>
  <style scoped>
  .footer {
    background: #06162a;
    text-align: center;
    padding: 97px 0;
    font-size: 0.8rem;
    color: #ccc;
  }
  </style>