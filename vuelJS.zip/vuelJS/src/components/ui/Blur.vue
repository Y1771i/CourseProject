<template>

    <div class="blur"></div>
</template>


<script>
export default {
  name: 'Blur',
}
</script>



<style scoped>
.blur {
  width: 987px; /* Указанная длина */
  border: 5px solid rgba(0, 0, 0, 0.5); /* Полупрозрачная граница */
  margin: 20px 200px
}
</style>