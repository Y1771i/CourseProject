<template>
    <footer class="footer">
      <div class="email-block">
        <span>✉️</span>
        <p>fiberify@gmail.com</p>
      </div>
    </footer>
  </template>
  
  <style scoped>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  .footer {
    background: #0A122A;
    padding: 113px;
    text-align: center;
    color: white;
  }
  .email-block span {
    display: block;
    font-size: 20px;
  }
  </style>