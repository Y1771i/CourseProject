<template>
  <div class="navbar">
    <div class="nav-left">
      
      <router-link to="/home" class="button-link">
        <img src="../../assets/logo.png" alt="Logo" class="logo" />
      </router-link>

      <div class="nav-links">
        <router-link to="/courses" class="button-link">Обучение</router-link>
        <router-link to="/library" class="button-link">Библиотека</router-link>
        <router-link to="#" class="button-link">О нас</router-link>
      </div>
    </div>
    <div class="profile-icon"></div>
  </div>
</template>

<script>

  

export default {
  name: 'Navbar'
  };

</script>


  
<style scoped>
  @import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap');


    .navbar {
      background-color: #0f3c66; 
      color: #FDFDFB;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 176px;
      margin-bottom: auto;
      /* border-bottom: 1px solid #ccc; */
    }
    
    .nav-left {
      display: flex;
      align-items: center;
      gap: 30px;
    }
    
    
    .nav-links .button-link {
      text-decoration: none;
      color: white;
      margin: 0 14px;
      font-family: 'Inter', sans-serif;
      font-size: 24px;
      font-weight: 400;
    }

    .profile-icon {
      width: 65px;
      height: 65px;
      background-image: url('../../assets/profile.png');
      /* background-size: cover; */
    }

/* Stop*/
</style>