<template>
    <div class="library-page">

      <div class="text_library">
        <p>Книги и методички</p>
      </div>

      <div class="search">
        <input type="text" placeholder="#" />
      </div>
      
      <div class="book-list">
        <BookCard
          v-for="(book, index) in books"
          :key="index"
          :image="book.image"
          :title="book.title"
          :description="book.description"
        />
      </div>
    </div>
    <Footer2 />
  </template>
  
  <script>
  import Navbar from '../components/ui/Navbar.vue'
  import BookCard from '../components/third_Page/BookCard.vue'
  import Footer2 from '../components/ui/Footer2.vue'
  
  export default {
    components: {
      Navbar,
      BookCard,
      Footer2,
    },
    data() {
      return {
        books: [
          //! Здесь можно добавить карточки! 
          { image: 'image1', title: 'Название книги 1', description: 'Немного о самой книге 1' },
          { image: 'image2', title: 'Название книги 2', description: 'Немного о самой книге 2' },
          { image: 'image3', title: 'Название книги 3', description: 'Немного о самой книге 3' },
          { image: 'image4', title: 'Название книги 4', description: 'Немного о самой книге 3' },
          { image: 'image5', title: 'Название книги 5', description: 'Немного о самой книге 3' },
          { image: 'image6', title: 'Название книги 6', description: 'Немного о самой книге 3' },
          { image: 'image7', title: 'Название книги 7', description: 'Немного о самой книге 3' },
          { image: 'image8', title: 'Название книги 8', description: 'Немного о самой книге 3' },
          { image: 'image9', title: 'Название книги 9', description: 'Немного о самой книге 3' },
          { image: 'image10', title: 'Название книги 10', description: 'Немного о самой книге 3' },
          { image: 'image11', title: 'Название книги 11', description: 'Немного о самой книге 3' },
          { image: 'image12', title: 'Название книги 12', description: 'Немного о самой книге 3' },

        ]
      }
    }
  }
  </script>
  
  <style scoped>

@import url('https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap');
  *{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  .text_library{
    display: inline-block;
    font-family: "Inter", sans-serif;
    font-size: 40px;
    font-weight: 400;
    padding: 0 532px;
    padding-bottom: 43px;
    color: #FDFDFB;

  }

  .library-page {
    background-color: #172451;
    color: #0c0c0b;
    padding: 3.688rem 0;
  }
  
  .search input {
    width: 40%;
    margin: 0 417px;
    padding: 0.5rem;
    margin-bottom: 2rem;
    border-radius: 30px;
  }
  
  .book-list {
    display: flex;
    flex-wrap: wrap;
    gap: 6rem;
    justify-content: center;
  }
  </style>