<template>

        <div class="sidebar">
            <nav>
            <a href="#">Новости</a>
            <a href="#">Мой прогресс</a>
            <a href="#">Профиль</a>
            </nav>
        </div>

        <div class="main">
            <div class="profile-image">
            <img src="../assets/photo8608769.png" alt="Фото пользователя">
            <br>
            <button class="btn">Обновить картинку</button>
            </div>

            <div class="profile-info">
            <p>Имя: <span>(user_name)</span></p>
            <p>Логин/Ник: <span>(user_nickname)</span></p>
            <p>Электронная Почта: <span>(user_email)</span></p>
            <p>Достижения: <span>(user_achievement)</span></p>
            </div>
        </div>
        <Footer/>
</template>


<script>
import Footer from '../components/ui/Footer2.vue'

export default {
  components: { 
    Footer,
  }
}
</script>


<style>
            @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Manrope:wght@200..800&display=swap');
            /* body {
            margin: 0;
            font-family: sans-serif;
            display: flex;
            height: 100vh;
            background-color: #121212;
            } */

            .sidebar {
            width: 200px;
            min-height: 87.9vh;
            background-color: #0A122A;
            color: white;
            padding: 20px;
            float: left;
            font-family: 'Inter', sans-serif;
            font-weight: 200;
            }

            .sidebar nav a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 15px; 
            font-size: 16px;
            }

            .main {
            height: 87.9vh;
            max-width: 190vh;
            background-color: #192c5c;
            color: white;
            padding: 40px;
            display: flex;
            align-items: flex-start;
            font-family: 'Inter', sans-serif;
            font-weight: 300;
            gap: 50px;
            }

            .profile-image {
            text-align: center;
            }

            .profile-image img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            background-color: #555;
            object-fit: cover;
            margin-bottom: 30px;
            }

            .btn {
            background-color: white;
            border: none;
            padding: 5px 25.8px;
            border-radius: 20px;
            color: #192c5c;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
            font-weight: 400;
            }

            .btn:hover {
            background-color: #e0e0e0;
            }

            .profile-info p {
            margin: 20px 0;
            font-size: 14px;
            }

            .profile-info span {
            font-weight: bold;
            color: #b8e0ff;
            }
</style>