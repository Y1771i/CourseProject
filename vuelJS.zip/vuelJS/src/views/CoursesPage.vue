<template>
  <div class="page">
    <CourseList />
    <Footer />
  </div>
</template>



<script>
import CourseList from '../components/second_Page/CourseList.vue';
import Footer from '../components/ui/Footer2.vue'

export default {
  components: { 
    CourseList, 
    Footer,
  }
}
</script>



<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
.page {
  background: #0A1B3A;
  min-height: 100vh;
}
</style>