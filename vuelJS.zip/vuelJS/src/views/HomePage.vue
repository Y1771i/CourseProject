<template>
    <div class="page">
      <Hero />
  
      <section class="info-section">
        <InfoCard />
      </section>
  
      <section class="courses"> 
        <CourseCard/>
      </section>
  
      <Footer />
    </div>
  </template>
  



<!--TODO: JS  -->
<script>
  import Navbar from '../components/ui/Navbar.vue'
  import Hero from '../components/first_Page/Hero.vue'
  import InfoCard from '../components/first_Page/InfoCard.vue'
  import CourseCard from '../components/first_Page/CourseCard.vue'
  import Footer from '../components/first_Page/Footer.vue'
  import Blur from '../components/ui/Blur.vue'
  
  
  export default {
    components: {
      Navbar,
      Hero,
      InfoCard,
      CourseCard,
      Footer,
      Blur,
    }
  };
</script>


  <!--TODO: CSS  -->

  <style scoped>
  .page {
    font-family: sans-serif;
    background-color: #0b1f3a;
    color: white;
  }
  
  .courses {
    padding: 13rem 1rem;
    text-align: center;
  }

  </style>