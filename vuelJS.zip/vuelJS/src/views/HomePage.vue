<template>
    <div class="page">
      <Hero />
  
      <section class="info-section">
        <InfoCard />
        <!-- <Blur /> -->
      </section>
  
      <section class="courses">
        <h2>Бесплатные курсы</h2>
        <div class="course-list">
          <CourseCard title="Начальный" />
          <CourseCard title="Средний" />
          <CourseCard title="Проме-жуточный" />
        </div>
  
        <h2>Платные курсы</h2>
        <div class="course-list">
          <CourseCard title="Продвинутый" />
        </div>
      </section>
  
      <Footer />
    </div>
  </template>
  

  <!--TODO: JS  -->

<script>
  import Navbar from '../components/ui/Navbar.vue'
  import Hero from '../components/first_Page/Hero.vue'
  import InfoCard from '../components/first_Page/InfoCard.vue'
  import CourseCard from '../components/first_Page/CourseCard.vue'
  import Footer from '../components/first_Page/Footer.vue'
  import Blur from '../components/ui/Blur.vue'

  
  
  export default {
    components: {
      Navbar,
      Hero,
      InfoCard,
      CourseCard,
      Footer,
      Blur,
    }
  };
</script>


  <!--TODO: CSS  -->

  <style scoped>
  .page {
    font-family: sans-serif;
    background-color: #0b1f3a;
    color: white;
  }
  
  .courses {
    padding: 13rem 1rem;
    text-align: center;
  }

  
  .course-list {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 15rem;
    margin-bottom: 4rem;
  }
  </style>