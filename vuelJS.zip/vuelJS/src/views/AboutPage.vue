<template>


  <div class="sidebar">
    <nav>
      <a href="#">Новости</a>
      <a href="#">Мой прогресс</a>
      <a href="#">Профиль</a>
    </nav>
  </div>

  <div class="main">
    <div class="news">
      <h2>Новость 1: (user_message)</h2>
      <button class="btn">Прочитать</button>
    </div>

    <div class="news">
      <p>Новость 2: (user_message)</p>
      <button class="btn">Прочитать</button>
    </div>

    <div class="news">
      <p>Новость 3: (user_message)</p>
      <button class="btn">Прочитать</button>
    </div>

    <div class="news">
      <p>Новость 4: (user_message)</p>
      <button class="btn">Прочитать</button>
    </div>
  </div>

</template>


<script>

</script>


<style>  

            .sidebar {
            width: 200px;
            background-color: #1a1a1a;
            color: white;
            padding: 20px;
            }

            .sidebar nav a {
            display: block;
            color: white;
            text-decoration: none;
            margin-bottom: 15px;
            font-size: 20px;
            }

            .main {
            display: flex;
            flex-direction: column;
            background-color: #192c5c;
            color: white;
            padding: 30px;
            }

            .news {
            margin-bottom: 30px;
            }

            .news h2 {
            margin: 0 0 10px;
            font-size: 20px;
            }

            .news p {
            color: #00bcd4;
            margin: 0 0 10px;
            }

            .btn {
            background-color: white;
            border: none;
            padding: 5px 55px;
            border-radius: 20px;
            color: #0B82A2;
            cursor: pointer;
            font-size: 14px;
            }

            .btn:hover {
            background-color: #bab7b7;
            }

</style>