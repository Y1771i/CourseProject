<template>
  <div id="app">
    <Navbar />
    <router-view /> 
 </div>
</template>
 
<script>
import Navbar from './components/ui/Navbar.vue';

export default {
 components: {
   Navbar,
 },
};
</script>
 
<style>
  * {
   margin: 0;
   padding: 0;
   box-sizing: border-box;
  }
</style>